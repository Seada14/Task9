var inp=document.querySelector("input")
inp.addEventListener("input",()=>{
    document.body.style.backgroundColor=inp.value;
})