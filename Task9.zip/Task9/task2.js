//1
// function num() {
//     for (var i = 1; i <= 10; i++) {
//       console.log(i);
//     }
//   }
  
//   num();

//2
// function arr() {
//     var array = [[1,2],[3,4],[5,6]];
  
//     for (var i = 0; i < array.length; i++) {
//       for (var j = 0; j < array[i].length; j++) {
//         console.log(array[i][j]);
//       }
//     }
//   }
//   arr();

//3
// function evenarray(array) {
   

//     for (var i = 0; i < array.length; i++) {
//         if (array[i] % 2 === 0) {
//           console.log(array[i]);
//         }
//       }
//     }
//     var array = [13,23,12,45,22,48,66,100]
//   evenarray(array);

//4

// function deleteElement(arr, element) {
//     for (var i = arr.length - 1; i >= 0; i--) {
//       if (arr[i] === element) {
//         arr.splice(i, 1);
//       }
//     }
//   }
  
//   var arr = [23, 56, 4, 78, 5, 63, 45, 210, 56];
//   deleteElement(arr, 56);
//   console.log(arr); 

//5

//6
// function Pattern(range) {
//     for (var i = 1; i <= range; i++) {
//       var pattern = '';
//       for (var j = 1; j <= i; j++) {
//         pattern += j + ' ';
//       }
//       console.log(pattern);
//     }
//   }
  
//   Pattern(10);

//7
// function Largest(array) {
//     var largestNumber = array[0];
//     for (var i = 1; i < array.length; i++) {
//       if (array[i] > largestNumber) {
//         largestNumber = array[i];
//       }
//     }
//     return largestNumber;
//   }
  
//   var arr = [2, 45, 3, 67, 34, 567, 34, 345, 123];
//   var largestNumber = Largest(arr);
//   console.log(largestNumber); 